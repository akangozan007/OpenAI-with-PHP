<?php
// Set the API endpoint URL and API key
$api_url = 'https://api.openai.com/v1/engines/davinci-codex/completions';
$api_key = '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';

// Get the message from the form data
$message = $_POST['tanya'];

// Create the request data
$data = array(
    'prompt' => 'Q: ' . $message . '\nA:',
    'temperature' => 0.7,
    'max_tokens' => 150,
    'stop' => '\n'
);

// Create the cURL request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Authorization: Bearer ' . $api_key
));

// Send the request and get the response
$response = curl_exec($ch);
curl_close($ch);

// Parse the response JSON and get the completed text
$response_data = json_decode($response, true);
$completed_text = $response_data['choices'][0]['text'];

// Output the completed text as a chat message
public function hasil() {
echo '<p>You: ' . htmlspecialchars($message) . '</p>';
echo '<p>ChatGPT: ' . htmlspecialchars($completed_text) . '</p>';
}