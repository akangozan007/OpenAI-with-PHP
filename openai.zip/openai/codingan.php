<!DOCTYPE html>
<html>

<head>
    <title>ChatGPT API Demo</title>
</head>

<body>
    <h1>ChatGPT API Demo</h1>
    <form method="POST" action="codingan2.php">
        <label for="message">Type your message:</label><br>
        <input type="text" id="message" name="message"><br><br>
        <input type="submit" value="Send">
    </form>
    <div id="chatlog"></div>
</body>

</html>